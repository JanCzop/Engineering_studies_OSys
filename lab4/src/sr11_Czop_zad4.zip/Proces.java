import java.util.ArrayList;

public class Proces {

    public ArrayList<Strona> strony;

    public Proces() {
        strony = new ArrayList<>();
    }


    public ArrayList<Strona> getStrony() {
        return strony;
    }

}