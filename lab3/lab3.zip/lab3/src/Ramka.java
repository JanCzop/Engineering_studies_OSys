public class Ramka {
    private Strona strona;
    public int czasUzycia=0;
    public int bitOdwolania=1;

    public Strona getStrona() {
        return strona;
    }

    public void setStrona(Strona strona) {
        this.strona = strona;
    }
}